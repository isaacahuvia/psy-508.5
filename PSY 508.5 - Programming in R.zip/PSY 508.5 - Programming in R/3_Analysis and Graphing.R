########################################
##       PSY 508 1/2: Intro to R      ##
##  Session 3: Analysis and Graphing  ##
##        Author: Isaac Ahuvia        ##
########################################

####  0. Setup  ####
rm(list = ls()) #This code erases anything left in your environment from a previous script
                #You don't have to use it, but I think it's best practice

library("stats")
library("tidyverse")
library("ggplot2")

cats <- read.csv("C:\\Users\\isaac\\Google Drive\\School\\PSY 508.5 - Programming in R\\Data\\clean_data.csv",
                 stringsAsFactors = F) #Anytime you use read.csv, you should specify stringsAsFactors = F



####  1. Analysis  ####
## 1a. ANOVA
#ANOVA is very simple in R. The main argument for this sort of function is the formula you want to test
#Formulas go like this: [dependent variable] ~ [independent variable(s)]
anova <- aov(formula = cats$heartWeight ~ cats$coat) #Do heart weights vary as a function of coat?
anova <- aov(data = cats, formula = heartWeight ~ coat) #Another way to write it
anova
#But wait... this isn't the output we expected?

#That's because this function gives us an output with a *ton* of information - as much as you could ever want about an ANOVA
str(anova)

#              _.---.._             _.---...__
#           .-'   /\   \          .'  /\     /
#          `.   (  )   \        /   (  )   /
#           `.  \/   .'\      /`.   \/  .'
#            ``---''   )    (   ``---''
#                   .';.--.;`.
#                .' /_...._\ `.
#              .'   `.a  a.'   `.
#             (        \/        )
#             `.___..-'`-..___.'
#               \          /
#                `-.____.-'  TOO MUCH ANOVA

#To get the summary table, run this
summary(anova)

#ANOVAs with Tukey adjustments are also easy. So are t-tests!
?TukeyHSD
?t.test


## 1b. Correlations
#Does body weight correlate with heart weight?
correlation <- cor(cats$bodyWeight, cats$heartWeight)
correlation #This gives us the correlation coefficient r, but nothing else

corDetails <- cor.test(cats$bodyWeight, cats$heartWeight)
corDetails #This gives us both r and the associated statistical test

#If you're working with large datasets, this can be a fun way to get a survey of what's going on
library("corrplot") #You might have to install this first! install.packages("corrplot")
cats.numeric <- select_if(cats,
                          ~ (is.numeric(.) | is.logical(.)))
corrplot(cor(cats.numeric))


## 1c. Linear Regression
linearModel <- lm(cats$bodyWeight ~ cats$cute + cats$kind) #Can we predict a cat's weight by how cute and kind it is?
str(linearModel) #This is also a huge output with lots of info
summary(linearModel) #This is the summary we generally want

plot(linearModel) #For checking assumptions
fitted(linearModel)
residuals(linearModel)
coef(linearModel)



####  2. Plots  ####
## 2a. "Grammar of Graphics"
# We use "ggplot" to graph things in R
# The "gg" in "ggplot" stands for "grammar of graphics"
# This refers to the weird way ggplot code works in R (nothing else really looks like it)
# Rather than plotting a complex plot with one giant function with 100 arguments,
# we build it in pieces. Let's see what that means.


#                                                               _...---.._
#                                                           _.'`       -_ ``.
#                                                       .-'`                 `.
#                                                   .-`                     q ;
#                                               _-`                       __  \
#                                          .-'`     You,         . ' .   \ `;/
#                                       _.-`    with the        /.      `._`/
#                              _...--'`         help of R       \_`..._
#                           .'`                         -         `'--:._
#                        .-`                           \                  `-.
#                       .                `              `-..__.....----...., `.
#                      '                 `  .''---..-''`'              : :  : :
#                    .` -                '`.                           `'   `'
#                 .-` .` '             .`'
#             _.-` .-`   '            .
#         _.-` _.-`    .' '         .`
# (`''--'' _.-`      .'  '        .'
#  `'----''        .'  .`       .`
#                .'  .'     .-'`                                     Data Insights
#              .'   :    .-`
#              `. .`   ,`
#               .'   .'
#              '   .`
#             '  .`
#             `  '.
#             `.___;


#All ggplot objects start like this
ggplot(cats)

#Or alternatively
cats %>%
  ggplot()

#You'll notice this makes a blank plot. The first things you need to give ggplot are the variables you want to plot
cats %>%
  ggplot(aes(x = bodyWeight, y = heartWeight))

#Now we know what is going to be represented in the plot. But how? For this plot, points probably makes the most sense
cats %>%
  ggplot(aes(x = bodyWeight, y = heartWeight)) +
  geom_point()


## 2b. Plot Types
#There are truly all types. Take a look at this site: https://www.r-graph-gallery.com/
#We already looked at dot plots. Let's quickly look at bar plots and histograms

#Bar plots are good for categorical values on the x-axis
cats %>%
  ggplot(aes(x = coat)) +
  geom_bar()

cats %>%
  group_by(coat) %>%
  summarize(meanBodyWeight = mean(bodyWeight)) %>%
  ggplot(aes(x = coat, y = meanBodyWeight)) +
  geom_col()

#Histograms are good for getting a sense of a continuous variable's distribution
cats %>% 
  ggplot(aes(x = bodyWeight)) +
  geom_histogram(bins = 10)


## 2c. Common Aesthetic Tweaks
#For a near-exhaustive list, see http://www.cookbook-r.com/Graphs/
cats %>%
  ggplot() +
  geom_point(aes(bodyWeight, heartWeight, color = coat), #aesthetics specified inside aes() *depend on another variable*
             size = 3) + #aesthetics specified outside of aes() *apply to everything*
  geom_smooth(aes(bodyWeight, heartWeight), #Add a linear fit line
              formula = "y ~ x", 
              method = "lm") +
  xlab("Body Weight (kg)") + #Add a label for the x-axis
  ylab("Heart Weight (kg)") + #Add a label for the y-axis
  ggtitle("Heart Weight by Body Weight") + #Add a title
  theme_light() #Change the overall look


## THE MOST IMPORTANT THING: If you're stuck, there's probably an easier way to do what you're doing!
## Consult the documentation, Google, StackOverflow, or a friend!
## A longer list of resources is on the bottom of file 4


#                        ,--------------------------.
#                       ( WOW! That's one smart cat )              .-.
#                       `--------------------------'               \ \
#                                      (_)                         \ \
#                                          O                       | |
#                     |\ /\                  o                     | |
#     __              |,\(_\_                  . /\---/\   _,---._ | |
#    ( (              |\,`   `-^.               /^   ^  \,'       `. ;
#     \ \             :    `-'   )             ( O   O   )  SPSS     ;
#      \ \             \        ;               `.=o=__,'            \
#       \ \             `-.   ,'                  /         _,--.__   \
#        \ \ ____________,'  (                   /  _ )   ,'   `-. `-. \
#         ; '                ;                  / ,' /  ,'        \ \ \ \
#         \     *^*~R~*^*   /___,-.            / /  / ,'          (,_)(,_)
#          `,    ,_____|  ;'_____,'           (,;  (,,)      
#        ,-" \  :      | :
#       ( .-" \ `.__   | |
#        \__)  `.__,'  |__)  



####  Appendix  ####

## A note on packages
# Sometimes you'll have two packages that *conflict* - they both have at least one function with the same name
# One example is filter(), which exists in the packages "dplyr" and "stats"
# By default, R will use the function from whichever package was loaded more recently
# To specify one or the other, use the package name followed by two colons, e.g. "dplyr::filter()"
# You can also use conflicted::conflict_prefer() to state which function should take precedence
