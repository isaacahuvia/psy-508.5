###########################################
##        PSY 508 1/2: Intro to R        ##
##  Session 1: Introduction and Vectors  ##
##         Author: Isaac Ahuvia          ##
###########################################

# Welcome to R!

# R is a programming language for statistics (but you can do all sorts of stuff with it)

# R is better than "point-and-click" programs for a lot of reasons
#   1. You type everything out. This gives you a paper trail of what you're doing,
#      makes it easy to tinker with and re-run data cleaning/analysis steps, 
#      and makes it possible to do replicable ***open science***
#   2. R is "open source" - lots of people have written special programs for it that
#      let you do stuff you can't do in other programs
#   3. R is free!!!

# To use R and follow along here, you'll need to download R and RStudio
# R: https://cloud.r-project.org/
# RStudio: https://rstudio.com/products/rstudio/download/#download
# Stop and do this before proceeding



####  1. Basics  ####
# This pane of the screen (upper left) is the *file editor*. This is where you write code
# The pane below this (bottom left) is the *console*. That is where code goes to be run
# The pane in the upper right is the *environment*. That is where you'll see your data
# The pane in the bottom right is the *viewer*. That's where you'll see your graphs (and other stuff)

#                        /)
#   "got it?"   /\___/\ ((
#              \`@_@'/  ))
#              {_:Y:.}_//
# ------------{_} ^ {_}----------

# To write code, just write it in this file, but don't start your line with a "#"
print("This is an example")

# To run code, highlight the code you want to run and press ctrl+enter
print("Try highlighting this line and clicking ctrl+enter") #Look in the console - you should see this printed out!
print("You can also click the 'Run' button in the upper right of this pane")

# Unlike SPSS, everything you do in R is done with code! This requires a learning curve, so hang in there



####  2. Vectors  ####
#   ,-.       _,---._ __  / \
#  /  )    .-'       `./ /   \
# (  (   ,'            `/    /|  "I thought we were working with data? Where is it?"
#  \  `-"             \'\   / |
#   `.              ,  \ \ /  |
#    /`.          ,'-`----Y   |
#   (            ;        |   '
#   |  ,-.    ,-'         |  /
#   |  | (   |            | /
#   )  |  \  `.___________|/
#  `--'   `--'

# Before we get to our "toy data", let's talk about *variables*
# Variables can be *values* (just single data points), or *vectors* (like columns in a dataset)
# It's really important to get an intuition around these, because just about everything R
# does behind the scenes ultimately relies on simple stuff you can do to vectors

# In the context of data, a "variable" is one of your measures, and can be independent, dependent, etc.
# In the context of R, that's still true, but we also refer to other things as "variables"
# In R, a variable is any object that we assign a value to. Once we assign a value to it,
# it shows up in our environment, and we can refer to that value by using its variable name.
# R is unique because you can work with "variables" like this that exist independendly of datasets

# Variables can be single values, like this variable
characterValue <- "This is a variable" #The "<-" means we're assigning the value on the right to the variable on the left
# This variable now appears in your environment

# Variables can also be vectors of multiple values, like this one
characterVector <- c("This", "is", "a", "vector") #The "c()" means it's a vector - separate values with commas

print(characterValue)
print(characterVector)

# Values and vectors can be made of characters or numbers (basically)

numericValue <- 5
numericVector <- c(1, 2, 3, 4)

print(numericValue)
print(numericVector)

# There's also a special type of vector called "logical" vectors - TRUE and FALSE
# It's important to remember that while these look like character vectors, they're
# actually numeric vectors "under the hood": 1 == TRUE and 0 == FALSE

logicalValue <- T
logicalVector <- c(T, T, F, F)

print(logicalValue)
print(logicalVector)

print(T + 1)
print(F - 10)

##########################################                            /\_/\            _
#                                        #                          = o_o =_______    \ \ 
#  VECTORS ARE THE BUILDING BLOCKS OF R  #                           |       __(  \.__) )
#                                        #  [x1, x2, x3, ..., xn]  <_____>__(_____)____/
##########################################

# Things you can do with vectors include:

# Do math to them
newVector <- numericVector + c(1, 1, 1, 1)
print(newVector)

anotherWay <- numericVector + 1
print(anotherWay)

# Test them logically
newVector == anotherWay #SUPER IMPORTANT - When you run this, what does it print to your console?

# These tests result in logical vectors that we can actually save and use later
ourTest <- newVector == anotherWay
print(ourTest)

newVector > anotherWay

newVector > 3.5

newVector > c(0, 1, 5, 10)

# When you save these logical vectors you can use them to *subset* other vectors
x <- characterVector == "This"
print(x)

# All of these are the same
characterVector[x] #The brackets say "where"; "show me characterVector where x (is true)"
characterVector[c(T, F, F, F)] #"Show me characterVector where c(T, F, F, F) (is true)"
characterVector[characterVector == "This"] #"Show me characterVector where characterVector == "This" (is true)"

# You can also subset vectors with the index of the value you want
characterVector[1] #"Show me characterVector in spot 1"
characterVector[4] #"Show me characterVector in spot 4"
subset <- characterVector[1:3] #"Save characterVector in spots 1 through 3"
print(subset)

# PLEASE DONT FALL ASLEEP YET! That's it for the boring stuff
#           __..--''``---....___   _..._    __
# /// //_.-'    .-/";  `        ``<._  ``.''_ `. / // /
#///_.-' _..--.'_    \                    `( ) ) // //
#/ (_..-' // (< _     ;_..__               ; `' / ///
# / // // //  `-._,_)' // / ``--...____..-' /// / //



####  Data  ####
# Datasets in R are generally called "data frames." They can be saved in a variety of formats,
# the most basic of which is .csv ("comma-separated values). Let's load one now
cats <- read.csv("C:\\Users\\isaac\\Google Drive\\School\\PSY 508.5 - Programming in R\\Data\\raw_data.csv",
                 stringsAsFactors = F)

# Note: You'll have to update the filepath to what it is for your computer. An easy way to get the filepath
# for your file is to type "file.choose()" into the console and press enter

# You should now see, along with all your vectors, the dataset "cats" in the environment (upper-right)
# Press the arrow next to it to see its variables
# You can get more information by using this code
summary(cats)
str(cats)
head(cats)

# To work with the full dataset, refer to it by its name ("cats")
print(cats)

# To work with an individual variable, refer to it by using the format "cats$[variable]"
print(cats$coat)

# We'll wrap up today by extending the vector operations we did before to the variables in this dataset
# Remember, VARIABLES IN A DATASETA ARE VECTORS. All the same stuff applies!
print(cats$bodyWeight)
print(cats$sex)

print(cats$bodyWeight[cats$sex == "male"])
print(cats$bodyWeight[cats$sex == "female"])

cats$weightInClothing <- cats$bodyWeight + 1 #This is the most basic way to create a new variable
print(cats$weightInClothing)

cats$heavy <- T
cats$heavy[cats$weightInClothing < 3] <- F
print(cats$heavy)

###########################################################
# A note on "functions"
# Everything you do with a "()" is a function (e.g. "print()")
# Functions have "syntax," or a grammar to them. If you use it wrong, R won't understand you
# Functions take "arguments," separated by commas ("print()" only takes one argument; "read.csv()" in line 159 took two)
# If you're confused about a function, there is help! Run "?[function]"
###########################################################

# Here are some built-in functions R gives you to analyze data. We'll cover these (and their upgraded versions) in week 3
hist(cats$bodyWeight)
mean(cats$bodyWeight)
table(cats$loved)

ANOVA <- aov(cats$bodyWeight ~ cats$coat) #"~" = "as a function of"; DV ~ IV
summary(ANOVA)
?aov

boxplot(cats$bodyWeight ~ cats$coat)

regression <- lm(cats$loved ~ cats$weightInClothing) #DV ~ IV
summary(regression)
?lm

#But these are all ugly! Here's a sneak peek at what we'll be able to do soon
install.packages("ggplot2") #Only run these lines once, then comment them out
install.packages("scales")
install.packages("tidyverse")
library(ggplot2)
library(scales)
library(tidyverse)
cats %>%
  ggplot() +
  geom_point(aes(bodyWeight, heartWeight, color = loved),
             size = 3) +
  geom_smooth(aes(bodyWeight, heartWeight), 
              formula = "y ~ x", 
              method = "lm") +
  xlab("Body Weight (kg)") +
  ylab("Heart Weight (kg)") +
  ggtitle("Heart Weight by Body Weight")



####  Appendix  ####

## Basic syntax
myBestFriend <- "Isaac" #assign a value to a variable in the environment
print(myBestFriend) #print to console
?print #get help
myBestFriend #print something to console (you don't actually need to use "print()")
1 #the number 1
c(1, 2, 3) #the vector 1 through 3
1:3 #another way to get a vector of sequential integers

subset #refer to a variable in the environment
cats$loved #refer to a variable from a dataset


## Arithmetic
1 + 2
1 - 2
1 * 2
1 / 2
2^2 #exponent
4 %% 3 #remainder


## Vector arithmetic
x <- 1:20
sum(x)
mean(x)
median(x)
min(x)
max(x)
range(x)
quantile(x)
length(x)
unique(x)

y <- c(1, 2, 3, NA)
mean(y)
mean(y, na.rm = T)


## Boolean logic
1 == 1 #equals
1 > 1 #greater than
1 >= 1 #greater than or equal to
1 < 1 #less than
1 <= 1 #less than or equal to
1 != 1 #not equal to
1 %in% c(1, 2, 3) #is 1 in the vector c(1, 2, 3)

1 == 1 & 2 == 2 #and
1 == 1 | 1 == 2 #or
!2 < 2 #not

## Subsetting
stringVector
stringVector == "This" #Creates a logical vector of which values in stringVector equal "This"
which(stringVector == "This") #Similar, but gives the index instead of a logical vector

stringVector[1]
stringVector[-1]
stringVector[c(T, F, F, F)]
stringVector[stringVector == "This"]
stringVector[numericVector == 1]

cats[1, 1] #Data frames have two dimensions. Subset them with [row, column]


## Changing data types
x <- c("1", "2", "3")
x
class(x)

y <- as.numeric(x)
y
class(y)

z <- as.character(y)
z
class(z)

## Factors
#There is another data type, called "factors" 
#These are numeric variables with character labels on them
#In general, I find it easiest to avoid these
#Most functions will treat character variables as factors when appropriate
?factor


## Working with .csv files
?write.csv #Always use row.names = F
?read.csv #Always use stringsAsFactors = F
