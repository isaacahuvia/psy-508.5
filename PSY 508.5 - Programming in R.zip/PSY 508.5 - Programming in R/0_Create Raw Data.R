#######################################
##  Create Raw Data For Instruction  ##
##         Not For Class Use         ##
#######################################

rm(list = ls())
library(tidyverse)

cats <- data.frame(
  coat = c(rep("calico", 10), rep("black", 10), rep("tabby", 10)),
  sex = rep(c(rep("male", 5), rep("female", 5)), 3),
  bodyWeight = round(rnorm(30, 3, .5), 2),
  loved = c(rep(T, 29), F)
) %>%
  mutate(bodyWeight = bodyWeight + if_else(sex == "male", .5, -.5) + if_else(coat == "black", .5, -.5) + if_else(loved == F, 3, 0),
         heartWeight = round((bodyWeight / 100) + rnorm(30, 0, .01), 3)) %>%
  select(coat, sex, bodyWeight, heartWeight, loved)

write.csv(cats, 
          file = "C:\\Users\\isaac\\Google Drive\\School\\PSY 508.5 - Programming in R\\Data\\raw_data.csv",
          row.names = F)
