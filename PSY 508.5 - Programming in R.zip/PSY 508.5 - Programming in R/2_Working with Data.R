####################################
##     PSY 508 1/2: Intro to R    ##
##  Session 2: Working with Data  ##
##      Author: Isaac Ahuvia      ##
####################################

# Today we'll learn about working with data, but before we get there, you need to know more about R

# Most of what you do in R will rely on add-ons called "packages" 
# The most common and useful packages are "tidyverse" and "ggplot2"
# To install these packages, run the code "install.packages()" with the package name (in quotes) in the parentheses
# Once they're installed, you still need to load them every time you run a script
# Because of that, the tops of our scripts will always look like this

library("tidyverse")
library("ggplot2")

# We also want to practice good code hygene. That means giving your scripts sections with headers, titles at the top, etc
# How you format this is totally up to you, but this is how I do it

####  1. Load Data  ####
# Remember to use file.choose()
cats <- read.csv("C:\\Users\\isaac\\Google Drive\\School\\PSY 508.5 - Programming in R\\Data\\raw_data.csv",
                 stringsAsFactors = F) #Anytime you use read.csv, you should specify stringsAsFactors = F



####  2. Clean Data  ####

# Now we'll cover some common data cleaning tasks you'll have to do
# In my experience, "data analysis" is 90% dataset manipulation and cleaning,
# and only 10% actual analysis

# All of the functions we use here are from the dplyr package in the "tidyverse." The author, Hadley Wickham,
# is essentially the de facto author of R. We'll focus on these functions:
?filter
?select
?mutate 
?group_by
?summarize

# We'll also learn about this thing "%>%" known as the "piping operator"


#        _                ___       _.--.
#       \`.|\..----...-'`   `-._.-'_.-'`
#      /  ' `         ,       __.--'
#      )/' _/     \   `-_,   /
#      `-'" `"\_  ,_.-;_.-\_ ',     on the hunt for insightsT
#          _.-'_./   {_.'   ; /
#        {_.-``-'         {_/


## 2a. Filtering datasets
# We use filter to subset our dataset
tabbies <- filter(cats,
                  coat == "tabby")
tabbies 

maleTabbies <- filter(cats,
                      coat == "tabby",
                      sex == "male")
maleTabbies

# Note that this is a more user-friendly way of doing subsetting with brackets! 
#Under the hood, filter is using brackets
tabbies2 <- cats[cats$coat == "tabby",] #Subsetting datasets requires two arguments: data[rows, columns]
                                        #Leave either one blank to include all rows or columns
tabbies2


## 2b. Selecting variables
# We use filter to keep only certain variables
coatAndSex <- select(cats,
                     coat,
                     sex)
coatAndSex

minusLoved <- select(cats,
                     -loved)
minusLoved

# Again, this is just an easier way of subsetting with brackets
coatAndSex2 <- cats[, c("coat", "sex")]
coatAndSex2


## 2c. Creating new variables with mutate
cats <- mutate(cats,
               cute = coat %in% c("calico", "tabby"),
               kind = heartWeight > (bodyWeight / 100))
cats

# This is the same as creating variables with the assigner "<-"
cats$ugly <- cats$coat == "black"
cats


## 2c*. Special note about editing data
# You can edit variables with mutate...
cats <- mutate(cats,
               kind = if_else(condition = loved == T, 
                               true = T, 
                               false = F))
cats$loved

# Or directly using the assigner "<-"
cats$loved[cats$loved == F] <- T
cats$loved


## 2d. group_by and summarize
# These functions let you create *summary statistics*
# With these 5 functions, you can do 75% of what you'll ever want to do in R
summarize(cats,
          mean = mean(heartWeight))
mean(cats$heartWeight)

# Let's find out the average heart weight by sex
summary <- summarize(group_by(cats,
                              sex), 
                     meanHeartWeight = mean(heartWeight)) 
summary
# But wait, what's happening here? Very hard to read. That's where "%>%" comes in
summary2 <- cats %>% #"Take the cats dataset..."
  group_by(sex) %>% #"...group by sex..."
  summarize(meanHeartWeight = mean(heartWeight)) #"...and summarize"
summary2

# The piping operator lets us do a lot of complex operations quickly and in a way that's easy to read
# What if we want to know the proportion of male cats that are cute, grouped by body weight (above/below median)?
cats %>%
  #First, flter to males only
  filter(sex == "male") %>%
  #Then, create a variable to denote body weight above/below median
  mutate(aboveMedian = bodyWeight > median(bodyWeight)) %>%
  #Now, group by that new variable
  group_by(aboveMedian) %>%
  #Now, summarize!
  summarize(proportionCute = mean(kind))


#                            _                        
#                           \`*-.                    
#                            )  _`-.                 
#                           .  : `. .                
#                           : _   '  \               
#                           ; *` _.   `*-._          
#                           `-.-'          `-.       
#                            ;       `       `.     
#                           :.       .        \    
#                          . \  .   :   .-'   .   
#                         '  `+.;  ;  '      :   
#                         :  '  |    ;       ;-. 
#                         ; '   : :`-:     _.`* ;
#                [bug] .*' /  .*' ; .*`- +'  `*' 
#                      `*-*   `*-*  `*-*'        


####  3. Save Data  ####
write.csv(cats, 
          "C:\\Users\\isaac\\Google Drive\\School\\PSY 508.5 - Programming in R\\Data\\clean_data.csv",
          row.names = F)

# Let's take a moment to point something out about functions. Run ?write.csv
# You'll see under "usage" it shows you the arguments x, file, and a bunch more
# You can use functions by *naming arguments* (like we just did with row.names = F),
# or by using "unnamed arguments" (like we just did for dataset and file location arguments in the first two lines)
# When you don't name an argument, the function assumes you want to go in order of how the arguments are written
# You can see how the arguments are written in "usage"



####  Appendix  ####

## If-then statements
# These often come in handy when creating new variables
?if_else
value <- 1
if_else(value == 1, "Equals 1", "Doesn't equal 1")

cats <- cats %>%
  mutate(heartSize = if_else(heartWeight < .03, "Tiny", "Large"))

cats$heartSize

# "case_when" is an extension of this logic
cats <- cats %>%
  mutate(heartSizeDetailed = case_when(heartWeight < .03 ~ "Tiny", #if...
                                       heartWeight >= .03 & heartWeight < .04 ~ "Medium", #...otherwise if...
                                       heartWeight >= .04 & heartWeight < .042 ~ "Huge", #...otherwise if...
                                       T ~ NA_character_)) #...otherwise...


## NA values
# These come up a lot, and are very important
# NA values can refer to missing data, or values where a condition doesn't make sense
# You can check for NA values with "count()", among other things
count(cats, heartSizeDetailed)
which(is.na(cats$heartSizeDetailed))


## Rename variables
?rename 
cats <- cats %>% rename(weight_body = bodyWeight)


## Arrange dataset by variable value
?arrange
cats <- cats %>% arrange(weight_body)
cats <- cats %>% arrange(desc(weight_body))


## Joining more than one dataset together
# This is too complicated to quickly explain, and is explored in more detail in section 4
# The functions you'll want to use are:
?left_join
?right_join
?inner_join
?full_join
?cbind
?rbind


## Reshaping data
# This is also too complicated to quickly explain, and is explored in more detail in section 4
?pivot_longer
?pivot_wider


## Other file types
# If you're only working with R, and you don't need the data to be readable by anyone else, use .rds
?saveRDS
?readRDS

# Another common issue is working with data from other programs. Here's a cheat sheet
# Excel data
library("openxlsx")
?read.xlsx
?write.xlsx

# SPSS, SAS, or Stata data
library("haven")
?read_spss
?read_sas
?read_stata
